package com.smartnet.projet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartnetplaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartnetplaceApplication.class, args);
	}

}
