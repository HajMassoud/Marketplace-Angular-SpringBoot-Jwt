package com.smartnet.projet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartnetplaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
